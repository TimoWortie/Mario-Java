package Main;
import java.awt.Canvas;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.image.BufferStrategy;
import java.awt.image.BufferedImage;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.JFrame;

import Entity.Entity;
import Entity.Player;
import Input.Key;
import Input.Mouse;
import gfx.ImageLoader;
import gfx.Sprite;
import gfx.Spritesheet;
import gfx.Statistics;

public class Game extends Canvas implements Runnable{

	public static int breite = 270,h�he = breite/14*10,scale = 4;
	public boolean running = false;
	public Thread thread = new Thread();
	public static Handler handler = new Handler();
	public static Player player = new Player(1000,500,100,100,true,handler,Id.player);
	public static Camera cam;
	
	public static Statistics s = new Statistics();
	private BufferedImage image,background;
	public static Spritesheet sheet;
	public static Sprite[] mario = new Sprite[31];
	public static Sprite grass,grass2,grass3,JoschiM�nze,m�nze,pipe,pipe2,block;
	
	public void init(){
		handler.addEntity(player);
		sheet = new Spritesheet("/Spritesheet.png");
		cam = new Camera();
		for(int i=0;i<mario.length;i++){
		mario[i] =  new Sprite(sheet,i+1,1,1,1);
		}
		block = new Sprite(sheet,14,2,1,1);
		JoschiM�nze = new Sprite(sheet,10,2,1,1);
		m�nze = new Sprite(sheet,11,2,1,1);
		pipe = new Sprite(sheet,12,2,1,1);
		pipe2 = new Sprite(sheet,13,2,1,1);
		addMouseListener(new Mouse());
		addKeyListener(new Key());
		try {
			image = ImageIO.read(getClass().getResource("/level.png"));
			background = ImageIO.read(getClass().getResource("/Background1.png"));
		} catch (IOException e) {}
		handler.createlevel(image);
	}
	
	public void render(){
		BufferStrategy bs = getBufferStrategy();
		if(bs==null){
			createBufferStrategy(3);
			return;
		}
		Graphics g = bs.getDrawGraphics();
		g.drawImage(background, 0, 0, getWidth(),getHeight(),null);
		s.render(g);
//		g.translate(cam.getX(), cam.getY()+220);
		handler.render(g);
		g.dispose();
		bs.show();
	}
	
	public void tick(){
		handler.tick();
		
		for(Entity e:handler.entity){
			if(e.getId()==Id.player){
				cam.tick(e);
			}
		}
		Statistics.timecounter++;
		if(Statistics.timecounter==60){
			Statistics.time--;
			Statistics.timecounter=0;
		}
		
		System.out.println(getWidth()+" "+getHeight());
	}
	
	public synchronized void start(){
		if(running) return;
		running = true;
		thread = new Thread(this);
		thread.start();
	}
	
	public synchronized void stop(){
		if(!running) return;
		running = false;
		try {
			thread.join();
		} catch (InterruptedException e) {}
	}
	
	public void run(){
		init();
		long lastTime = System.nanoTime();
		long timer = System.currentTimeMillis();
		double delta = 0.0;
		double nanosecounds = 1000000000.0/60.0;
		int frames = 0;
		int ticks = 0;
		while(running){
			long now = System.nanoTime();
			delta+=(now-lastTime)/nanosecounds;
			lastTime = now;
			while(delta>=1){
				tick();
				ticks++;
				delta--;
			}
			render();
			frames++;
			if(System.currentTimeMillis()-timer>1000){
				timer+=1000;
				frames = 0;
				ticks = 0;
			}
		}
		stop();
	}
	
	public Game(){
		Dimension size = new Dimension(breite*scale,h�he*scale);
		setPreferredSize(size);
		setMinimumSize(size);
		setMaximumSize(size);
	}
	
	public static int getFrameBreite(){
		return breite*scale;
	}
	
	public static int getFrameH�he(){
		return h�he*scale;
	}
	
	public static void main(String[] args){
		Game game = new Game();
		JFrame frame = new JFrame();
		frame.add(game);
		frame.pack();
		frame.setBounds(1920,0,1280,720);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setVisible(true);
		game.start();
	}
}
