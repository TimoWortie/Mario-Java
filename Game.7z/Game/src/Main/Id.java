package Main;

public enum Id {
	wall,player,joschim�nze,m�nze,pipe;
}
