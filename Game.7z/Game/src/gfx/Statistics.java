package gfx;

import java.awt.Color;
import java.awt.Graphics;

import Main.Game;

public class Statistics {
	
	public static int timecounter,time=400,joschim�nzen,m�nze;
	
	public void render(Graphics g){
		g.setColor(Color.blue);
		g.drawString(Integer.toString(time)+"     "+Integer.toString(joschim�nzen)+"     "+Integer.toString(m�nze), 100, 100);
	}
	
	public void tick(){
		
	}

}
