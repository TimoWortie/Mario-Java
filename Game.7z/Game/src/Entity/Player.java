package Entity;

import java.awt.Color;
import java.awt.Graphics;

import Input.Key;
import Input.Mouse;
import Main.Game;
import Main.Handler;
import Main.Id;
import Tile.JoschiM�nze;
import Tile.Tile;
import gfx.Statistics;

public class Player extends Entity{

	int frame,framedelay;
	public static int moving=-1;
	
	public Player(int x, int y, int breite, int h�he, boolean solid, Handler handler, Id id) {
		super(x, y, breite, h�he, solid, handler, id);
	}
	
	public void render(Graphics g){
		if(moving==-1&&!jumping&&!falling){g.drawImage( Game.mario[0].getBufferedImage(), x, y, breite,h�he,null);}
		if(moving==1&&!jumping&&!falling){g.drawImage( Game.mario[frame].getBufferedImage(), x, y, breite,h�he,null);}
		if(moving==1&&jumping&&!falling){g.drawImage( Game.mario[26].getBufferedImage(), x, y, breite,h�he,null);}
		if(moving==1&&!jumping&&falling){g.drawImage( Game.mario[28].getBufferedImage(), x, y, breite,h�he,null);}
		if(moving==-1&&jumping&&!falling){g.drawImage( Game.mario[26].getBufferedImage(), x, y, breite,h�he,null);}
		if(moving==-1&&!jumping&&falling){g.drawImage( Game.mario[28].getBufferedImage(), x, y, breite,h�he,null);}
		
		if(moving==-2&&!jumping&&!falling){g.drawImage( Game.mario[13].getBufferedImage(), x, y, breite,h�he,null);}
		if(moving==2&&!jumping&&!falling){g.drawImage( Game.mario[frame+14].getBufferedImage(), x, y, breite,h�he,null);}
		if(moving==2&&jumping&&!falling){g.drawImage( Game.mario[27].getBufferedImage(), x, y, breite,h�he,null);}
		if(moving==2&&!jumping&&falling){g.drawImage( Game.mario[29].getBufferedImage(), x, y, breite,h�he,null);}
		if(moving==-2&&jumping&&!falling){g.drawImage( Game.mario[27].getBufferedImage(), x, y, breite,h�he,null);}
		if(moving==-2&&!jumping&&falling){g.drawImage( Game.mario[29].getBufferedImage(), x, y, breite,h�he,null);}
	}
	
	public void tick(){	
		x+=velX;
		y+=velY;
		
		for(Tile t:handler.tile){
			if(t.getId()==Id.wall){
				if(getTop().intersects(t.getBounds())){
					setVelY(0);
					y=t.getY()+70;
					jumping=false;
					falling=true;
				}
				
				if(getBottom().intersects(t.getBounds())){
					setVelY(0);
					y=t.getY()-100;
					if(falling){ falling = false;}
					}else if(!jumping){
						falling=true;
						}
				
				if(getLeft().intersects(t.getBounds())){
					setVelX(0);
					x=t.getX()+40;
				}
				if(getRight().intersects(t.getBounds())){
					setVelX(0);
					x=t.getX()-75;
				}
			  }
			if(t.getId()==Id.joschim�nze){
				if(getBounds().intersects(t.getBoundsJoschiM�nze())){
					Handler.joschim�nze.setAsRemoved();
					Statistics.joschim�nzen++;
				}
			}
			if(t.getId()==Id.m�nze){
			if(getBounds().intersects(t.getBoundsM�nze())){
				Handler.m�nze.setAsRemoved();
				Statistics.m�nze++;
			}
			}
			}

		if(jumping){
			gravity-=0.5f;
			setVelY((int)-gravity);
			if(gravity<=0.0f){
				falling=true;
				jumping=false;
			}
		}
		if(falling){
			gravity+=0.5f;
			for(Tile t:handler.tile){
				if(t.getId()==Id.wall){
					if(getBottom().intersects(t.getBounds())){
						gravity = 0f;
						jumping = false;
						falling = false;
					}
				}
			}
			setVelY((int)gravity);
		}
		framedelay++;
		if(Key.d&&Key.shift||Key.a&&Key.shift){
			if(framedelay>=5){
				frame++;
				if(frame>=5){
					frame=0;
				}
				framedelay=0;
			}
		}else if(framedelay>=6){
			frame++;
			if(frame>=5){
				frame=0;
			}
			framedelay=0;
		}
		
		if(Key.d&&Key.shift){
			setVelX(8);
			Player.moving=1;
		}else if(Key.d&&!Key.shift){
			setVelX(5);
			Player.moving=1;
		}
		
		if(Key.a&&Key.shift){
			setVelX(-8);
			Player.moving=2;
		}else if(Key.a&&!Key.shift){
			setVelX(-5);
			Player.moving=2;
		}
	  }
	}