package Tile;

import java.awt.Color;
import java.awt.Graphics;

import Main.Game;

public class Items extends Tile{

	public Items(int x, int y, int breite, int h�he, boolean solid) {
		super(x, y, breite, h�he, solid);
		}

	public void render(Graphics g){
		g.setColor(Color.black);
		g.fillRect(x, y, breite, h�he);
	}
	
	public void tick(){
	}
}
